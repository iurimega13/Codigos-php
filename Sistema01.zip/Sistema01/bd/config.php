<?php
 define("HOST","localhost");
 define("USUARIO","root");
 define("DB" ,'empresa');
 define("SENHA",'root');
?>